print("What is your age?")
age = input()
age = int(age)
dogAge = age * 7
print("If you were a dog, you'd be" , dogAge , "!!")
print('''
 '0'_____'
    || ||
''')
