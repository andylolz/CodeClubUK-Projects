print("What year were you born?")
born = input()
born = int(born)

print("For what year do you want to know your age?")
year = input()
year = int(year)

print( "In the year" , year, "you will be" , year - born  , "years old!" )
