print("My favourite animals are sheep:")
print('''
  o-###-
    | |   #
''')
print("I live in Glasgow:")
print('''
   _|_
  |   |
  |#  |____
  |   |    |
  |  #|  # |
  |   | #  |''')
