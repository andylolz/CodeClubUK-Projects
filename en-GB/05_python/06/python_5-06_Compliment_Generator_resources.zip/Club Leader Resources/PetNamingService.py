from random import *

print("Pet naming service")
print("------------------")

names = ["Bob", "Fluffy", "Martin", "Spot"]

#print a random name in the 'names' list
print("You should name your new pet" , choice(names))
